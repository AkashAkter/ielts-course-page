"use client";
import type { CtaText, ProductData } from "@/types/product";

interface CTASectionProps {
  ctaText: CtaText;
  productData: ProductData;
  currentLang: "en" | "bn";
}

export default function CTASection({ ctaText, currentLang }: CTASectionProps) {
  const price = 1000;
  const priceDisplay = currentLang === "en" ? `৳${price}` : `${price} টাকা`;

  return (
    <section className="bg-white rounded-2xl p-5 xl:p-8 shadow-md flex flex-col gap-4 text-center">
      <h3 className="text-xl xl:text-2xl font-semibold text-gray-800">
        {priceDisplay}
      </h3>

      <button
        className={`
          w-full px-5 py-3 xl:px-6 xl:py-4 rounded-xl font-semibold text-base xl:text-lg 
          transition-transform duration-200 flex items-center justify-center gap-2
          hover:scale-105 active:scale-95 focus:outline-none focus:ring-2 focus:ring-offset-2
          bg-[#1CAB55] text-white hover:bg-green-600 focus:ring-[#1CAB55]
        `}
        aria-label={ctaText?.name || "Enroll Now"}
      >
        {ctaText?.name || "Enroll Now"}
      </button>
    </section>
  );
}
